import http from 'http';
import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import bodyParser from 'body-parser';
import WebSocketServer, {Server} from 'uws';


const PORT = 8000;
const app = express();
app.server = http.createServer(app);


app.use(morgan('dev'));


app.use(cors({
    exposedHeaders: "*"
}));

app.use(bodyParser.json({
    limit: '50mb'
}));

app.wss = new Server({
 
  server: app.server

});


let istemciler = [];

app.wss.on('connection' ,(connection) => {


const kullanicid = istemciler.length + 1;

connection.kullanicid = kullanicid

const yeniKullanici = {

	ws: connection,
	kullanicid: kullanicid,

};

 istemciler.push(yeniKullanici);

 console.log("Istemci su ID ile baglanti kurdu : " , kullanicid);


connection.on('message', (message) => {

     console.log("Surdan mesaj var : " , message);

   });


connection.on('close', () => {

     console.log("Istemci ", kullanicid , ' cikis yapti.');

     istemciler = istemciler.filter((Istemci) => Istemci.kullanicid !== kullanicid);

   });

});

app.get('/',(reg, res) => {

res.json({

version: version

    });

});

app.get('/api/all_connections' ,(reg , res , next) => {

return res.json({

   people: istemciler,

    });

});

setInterval(() => {

   // 3 saniyede bir calisicak 
   console.log(`Cevrimici olan ${istemciler.length} kullanici var.`);

   if (istemciler.length > 0) {}

       istemciler.forEach((Istemci) => {

       //console.log("Istemci ID : " , Istemci.kullanicid);

       const msj = `Merhaba ID: ${Istemci.kullanicid} sunucudan yeni bir mesajin var !` ;

       Istemci.ws.send(msj);

       });

} , 3000)


app.server.listen(process.env.PORT || PORT, () => {
        console.log(`Uygulamanın çalıştığı port numarası ${app.server.address().port}`);
});

export default app;